# Sample Law Firm Website

Learn how to build a completely custom website using WordPress, PHP, HTML, and CSS. You will learn how set up your local server, create the design, and build a custom WordPress theme that works with Elementor. 

A sample law firm website created for Free Code Camp (https://www.youtube.com/channel/UC8butISFwT-Wl7EV0hUK0BQ)

Youtube URL: https://www.youtube.com/watch?v=IPo71JPKUmg

